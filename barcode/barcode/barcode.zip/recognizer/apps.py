from django.apps import AppConfig


class RecognizerConfig(AppConfig):
    name = 'recognizer'
